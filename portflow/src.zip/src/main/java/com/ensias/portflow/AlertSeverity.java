package com.ensias.portflow;

public enum AlertSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}
