package com.ensias.portflow;

class EquipmentFailureRequest {
    private String equipmentName;
    private String description;
    
    // Getters and Setters
    public String getEquipmentName() { return equipmentName; }
    public void setEquipmentName(String equipmentName) { this.equipmentName = equipmentName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
