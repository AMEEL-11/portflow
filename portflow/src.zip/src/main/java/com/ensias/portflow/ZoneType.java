package com.ensias.portflow;

public enum ZoneType {
    STANDARD, REFRIGERATED, HAZARDOUS, OVERSIZE
}
