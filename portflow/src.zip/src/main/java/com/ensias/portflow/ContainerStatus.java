package com.ensias.portflow;

public enum ContainerStatus {
	ARRIVING, UNLOADING, STORED, LOADING, DEPARTED, IN_TRANSIT
}
