package com.ensias.portflow;

public enum LocationStatus {
    AVAILABLE, OCCUPIED, RESERVED, MAINTENANCE
}