package com.ensias.portflow;

public enum EscaleStatus {
    PLANNED, IN_APPROACH, DOCKED, LOADING_UNLOADING, DEPARTED
}
