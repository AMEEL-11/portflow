package com.ensias.portflow;

public enum AlertType {
    EQUIPMENT_FAILURE, STORAGE_CAPACITY, SHIP_DELAY, CONTAINER_OVERDUE, SYSTEM_ERROR
}

