package com.ensias.portflow;

public enum MovementType {
    DISCHARGE, LOAD, YARD_IN, YARD_OUT, GATE_IN, GATE_OUT, RESTOW
}